from flask import Blueprint, jsonify, request
from flask_cors import cross_origin
from src.models.client import Client, db
from sqlalchemy.exc import IntegrityError

client_bp = Blueprint('client', __name__)

@client_bp.route('/clients', methods=['GET'])
@cross_origin()
def get_clients():
    """
    Busca todos os clientes
    """
    try:
        clients = Client.query.all()
        return jsonify([client.to_dict() for client in clients]), 200
    except Exception as e:
        return jsonify({'error': 'Erro ao buscar clientes', 'message': str(e)}), 500

@client_bp.route('/clients', methods=['POST'])
@cross_origin()
def create_client():
    """
    Cria um novo cliente
    """
    try:
        data = request.json
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        # Cria instância do cliente
        client = Client.from_dict(data)
        
        # Valida os dados
        validation = client.validate()
        if not validation['is_valid']:
            return jsonify({
                'error': 'Dados inválidos',
                'errors': validation['errors']
            }), 400
        
        # Salva no banco de dados
        db.session.add(client)
        db.session.commit()
        
        return jsonify(client.to_dict()), 201
        
    except IntegrityError as e:
        db.session.rollback()
        return jsonify({
            'error': 'Email já cadastrado',
            'message': 'Este email já está sendo usado por outro cliente'
        }), 409
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Erro ao criar cliente', 'message': str(e)}), 500

@client_bp.route('/clients/<string:client_id>', methods=['GET'])
@cross_origin()
def get_client(client_id):
    """
    Busca um cliente por ID
    """
    try:
        client = Client.query.get_or_404(client_id)
        return jsonify(client.to_dict()), 200
    except Exception as e:
        return jsonify({'error': 'Cliente não encontrado', 'message': str(e)}), 404

@client_bp.route('/clients/<string:client_id>', methods=['PUT'])
@cross_origin()
def update_client(client_id):
    """
    Atualiza um cliente existente
    """
    try:
        client = Client.query.get_or_404(client_id)
        data = request.json
        
        if not data:
            return jsonify({'error': 'Dados não fornecidos'}), 400
        
        # Atualiza os dados
        client.update_from_dict(data)
        
        # Valida os dados
        validation = client.validate()
        if not validation['is_valid']:
            return jsonify({
                'error': 'Dados inválidos',
                'errors': validation['errors']
            }), 400
        
        # Salva as alterações
        db.session.commit()
        
        return jsonify(client.to_dict()), 200
        
    except IntegrityError as e:
        db.session.rollback()
        return jsonify({
            'error': 'Email já cadastrado',
            'message': 'Este email já está sendo usado por outro cliente'
        }), 409
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Erro ao atualizar cliente', 'message': str(e)}), 500

@client_bp.route('/clients/<string:client_id>', methods=['DELETE'])
@cross_origin()
def delete_client(client_id):
    """
    Remove um cliente
    """
    try:
        client = Client.query.get_or_404(client_id)
        db.session.delete(client)
        db.session.commit()
        return '', 204
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Erro ao deletar cliente', 'message': str(e)}), 500

@client_bp.route('/clients/health', methods=['GET'])
@cross_origin()
def health_check():
    """
    Endpoint de verificação de saúde da API
    """
    return jsonify({
        'status': 'healthy',
        'message': 'API de clientes funcionando corretamente',
        'version': '1.0.0'
    }), 200

