from flask_sqlalchemy import SQLAlchemy
from src.models.user import db
import uuid

class Client(db.Model):
    """
    Modelo de dados para Cliente
    """
    __tablename__ = 'clients'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    nome = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    telefone = db.Column(db.String(20), nullable=False)
    
    def __repr__(self):
        return f'<Client {self.nome}>'
    
    def to_dict(self):
        """
        Converte o objeto Cliente para dicionário
        """
        return {
            'id': self.id,
            'nome': self.nome,
            'email': self.email,
            'telefone': self.telefone
        }
    
    @classmethod
    def from_dict(cls, data):
        """
        Cria uma instância de Cliente a partir de um dicionário
        """
        return cls(
            nome=data.get('nome'),
            email=data.get('email'),
            telefone=data.get('telefone')
        )
    
    def update_from_dict(self, data):
        """
        Atualiza os campos do cliente a partir de um dicionário
        """
        self.nome = data.get('nome', self.nome)
        self.email = data.get('email', self.email)
        self.telefone = data.get('telefone', self.telefone)
    
    def validate(self):
        """
        Valida os dados do cliente
        """
        errors = []
        
        if not self.nome or not self.nome.strip():
            errors.append('Nome é obrigatório')
        
        if not self.email or not self.email.strip():
            errors.append('Email é obrigatório')
        elif '@' not in self.email or '.' not in self.email:
            errors.append('Email deve ter um formato válido')
        
        if not self.telefone or not self.telefone.strip():
            errors.append('Telefone é obrigatório')
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors
        }

