import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog.jsx';
import { Edit, Trash2, Mail, Phone, User } from 'lucide-react';

/**
 * Componente de lista de clientes
 */
export function ClientList({ clients, onEdit, onDelete, isLoading }) {
  const [deletingId, setDeletingId] = useState(null);

  /**
   * Confirma e executa a exclusão do cliente
   */
  const handleDelete = async (client) => {
    setDeletingId(client.id);
    try {
      await onDelete(client.id);
    } catch (error) {
      console.error('Erro ao deletar cliente:', error);
    } finally {
      setDeletingId(null);
    }
  };

  /**
   * Renderiza um card de cliente
   */
  const ClientCard = ({ client }) => (
    <Card key={client.id} className="w-full">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1 space-y-2">
            {/* Nome do cliente */}
            <div className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              <h3 className="font-semibold text-lg">{client.nome}</h3>
            </div>
            
            {/* Email */}
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Mail className="h-4 w-4" />
              <span>{client.email}</span>
            </div>
            
            {/* Telefone */}
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Phone className="h-4 w-4" />
              <span>{client.telefone}</span>
            </div>
            
            {/* ID do cliente */}
            {client.id && (
              <div className="pt-1">
                <Badge variant="secondary" className="text-xs">
                  ID: {client.id}
                </Badge>
              </div>
            )}
          </div>
          
          {/* Botões de ação */}
          <div className="flex gap-2 ml-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onEdit(client)}
              className="h-8 w-8 p-0"
            >
              <Edit className="h-4 w-4" />
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                  disabled={deletingId === client.id}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
                  <AlertDialogDescription>
                    Tem certeza que deseja excluir o cliente <strong>{client.nome}</strong>?
                    Esta ação não pode ser desfeita.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => handleDelete(client)}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    {deletingId === client.id ? 'Excluindo...' : 'Excluir'}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  // Estado de carregamento
  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="text-muted-foreground">Carregando clientes...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Lista vazia
  if (!clients || clients.length === 0) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Clientes Cadastrados</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertDescription>
              Nenhum cliente cadastrado ainda. Use o formulário acima para adicionar o primeiro cliente.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  // Lista com clientes
  return (
    <div className="w-full space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Clientes Cadastrados</span>
            <Badge variant="secondary">
              {clients.length} {clients.length === 1 ? 'cliente' : 'clientes'}
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>
      
      <div className="space-y-3">
        {clients.map(client => (
          <ClientCard key={client.id || client.email} client={client} />
        ))}
      </div>
    </div>
  );
}

