import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { Client } from '../models/Client.js';

/**
 * Componente de formulário para criar/editar clientes
 */
export function ClientForm({ client, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    telefone: ''
  });
  const [errors, setErrors] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Preenche o formulário quando um cliente é passado para edição
  useEffect(() => {
    if (client) {
      setFormData({
        nome: client.nome || '',
        email: client.email || '',
        telefone: client.telefone || ''
      });
    } else {
      setFormData({
        nome: '',
        email: '',
        telefone: ''
      });
    }
    setErrors([]);
  }, [client]);

  /**
   * Atualiza os dados do formulário
   */
  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    // Limpa erros quando o usuário começa a digitar
    if (errors.length > 0) {
      setErrors([]);
    }
  };

  /**
   * Submete o formulário
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrors([]);

    try {
      // Cria instância do cliente com os dados do formulário
      const clientData = new Client(
        client?.id || null,
        formData.nome.trim(),
        formData.email.trim(),
        formData.telefone.trim()
      );

      // Valida os dados
      const validation = clientData.validate();
      if (!validation.isValid) {
        setErrors(validation.errors);
        return;
      }

      // Chama a função de callback para salvar
      await onSave(clientData);

      // Limpa o formulário após salvar
      if (!client) { // Só limpa se for criação (não edição)
        setFormData({
          nome: '',
          email: '',
          telefone: ''
        });
      }
    } catch (error) {
      setErrors([error.message || 'Erro ao salvar cliente']);
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Cancela a edição
   */
  const handleCancel = () => {
    setFormData({
      nome: '',
      email: '',
      telefone: ''
    });
    setErrors([]);
    if (onCancel) {
      onCancel();
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>
          {client ? 'Editar Cliente' : 'Novo Cliente'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Exibe erros de validação */}
          {errors.length > 0 && (
            <Alert variant="destructive">
              <AlertDescription>
                <ul className="list-disc list-inside">
                  {errors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {/* Campo Nome */}
          <div className="space-y-2">
            <Label htmlFor="nome">Nome *</Label>
            <Input
              id="nome"
              type="text"
              value={formData.nome}
              onChange={(e) => handleInputChange('nome', e.target.value)}
              placeholder="Digite o nome do cliente"
              disabled={isSubmitting}
            />
          </div>

          {/* Campo Email */}
          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder="Digite o email do cliente"
              disabled={isSubmitting}
            />
          </div>

          {/* Campo Telefone */}
          <div className="space-y-2">
            <Label htmlFor="telefone">Telefone *</Label>
            <Input
              id="telefone"
              type="tel"
              value={formData.telefone}
              onChange={(e) => handleInputChange('telefone', e.target.value)}
              placeholder="Digite o telefone do cliente"
              disabled={isSubmitting}
            />
          </div>

          {/* Botões */}
          <div className="flex gap-2 pt-4">
            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="flex-1"
            >
              {isSubmitting ? 'Salvando...' : (client ? 'Atualizar' : 'Salvar')}
            </Button>
            
            {client && (
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleCancel}
                disabled={isSubmitting}
              >
                Cancelar
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

