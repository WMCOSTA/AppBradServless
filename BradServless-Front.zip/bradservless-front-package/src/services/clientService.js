import { Client } from '../models/Client.js';

/**
 * Serviço para comunicação com a API de clientes
 */
class ClientService {
  constructor() {
    // URL base da API - será configurada via variável de ambiente
    this.baseURL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api';
  }

  /**
   * Configurações padrão para requisições
   */
  getDefaultHeaders() {
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
  }

  /**
   * Trata erros de resposta da API
   * @param {Response} response 
   */
  async handleResponse(response) {
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `Erro HTTP: ${response.status}`);
    }
    return response.json();
  }

  /**
   * Busca todos os clientes
   * @returns {Promise<Client[]>}
   */
  async getAllClients() {
    try {
      const response = await fetch(`${this.baseURL}/clients`, {
        method: 'GET',
        headers: this.getDefaultHeaders()
      });

      const data = await this.handleResponse(response);
      return data.map(clientData => Client.fromJSON(clientData));
    } catch (error) {
      console.error('Erro ao buscar clientes:', error);
      throw error;
    }
  }

  /**
   * Busca cliente por ID
   * @param {string} id 
   * @returns {Promise<Client>}
   */
  async getClientById(id) {
    try {
      const response = await fetch(`${this.baseURL}/clients/${id}`, {
        method: 'GET',
        headers: this.getDefaultHeaders()
      });

      const data = await this.handleResponse(response);
      return Client.fromJSON(data);
    } catch (error) {
      console.error('Erro ao buscar cliente:', error);
      throw error;
    }
  }

  /**
   * Cria novo cliente
   * @param {Client} client 
   * @returns {Promise<Client>}
   */
  async createClient(client) {
    try {
      const validation = client.validate();
      if (!validation.isValid) {
        throw new Error(`Dados inválidos: ${validation.errors.join(', ')}`);
      }

      const response = await fetch(`${this.baseURL}/clients`, {
        method: 'POST',
        headers: this.getDefaultHeaders(),
        body: JSON.stringify(client.toJSON())
      });

      const data = await this.handleResponse(response);
      return Client.fromJSON(data);
    } catch (error) {
      console.error('Erro ao criar cliente:', error);
      throw error;
    }
  }

  /**
   * Atualiza cliente existente
   * @param {string} id 
   * @param {Client} client 
   * @returns {Promise<Client>}
   */
  async updateClient(id, client) {
    try {
      const validation = client.validate();
      if (!validation.isValid) {
        throw new Error(`Dados inválidos: ${validation.errors.join(', ')}`);
      }

      const response = await fetch(`${this.baseURL}/clients/${id}`, {
        method: 'PUT',
        headers: this.getDefaultHeaders(),
        body: JSON.stringify(client.toJSON())
      });

      const data = await this.handleResponse(response);
      return Client.fromJSON(data);
    } catch (error) {
      console.error('Erro ao atualizar cliente:', error);
      throw error;
    }
  }

  /**
   * Remove cliente
   * @param {string} id 
   * @returns {Promise<void>}
   */
  async deleteClient(id) {
    try {
      const response = await fetch(`${this.baseURL}/clients/${id}`, {
        method: 'DELETE',
        headers: this.getDefaultHeaders()
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `Erro HTTP: ${response.status}`);
      }
    } catch (error) {
      console.error('Erro ao deletar cliente:', error);
      throw error;
    }
  }
}

// Exporta instância singleton do serviço
export const clientService = new ClientService();

