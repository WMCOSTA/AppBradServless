import { HomePage } from './pages/HomePage.jsx';
import './App.css'

function App() {
  return <HomePage />;
}

export default App
