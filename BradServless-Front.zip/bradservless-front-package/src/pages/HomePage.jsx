import { useState, useEffect } from 'react';
import { ClientForm } from '../components/ClientForm.jsx';
import { ClientList } from '../components/ClientList.jsx';
import { clientService } from '../services/clientService.js';
import { Alert, AlertDescription } from '@/components/ui/alert.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Separator } from '@/components/ui/separator.jsx';
import { RefreshCw, Plus, AlertCircle } from 'lucide-react';

/**
 * Página principal da aplicação de cadastro de clientes
 */
export function HomePage() {
  const [clients, setClients] = useState([]);
  const [editingClient, setEditingClient] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);

  /**
   * Carrega a lista de clientes
   */
  const fetchClients = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const clientsData = await clientService.getAllClients();
      setClients(clientsData);
    } catch (error) {
      console.error('Erro ao carregar clientes:', error);
      setError(error.message || 'Erro ao carregar clientes');
      // Em caso de erro, usar dados mock para demonstração
      setClients([]);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Carrega clientes na inicialização
   */
  useEffect(() => {
    fetchClients();
  }, []);

  /**
   * Salva cliente (criar ou atualizar)
   */
  const handleSaveClient = async (client) => {
    try {
      setError(null);
      
      if (editingClient) {
        // Atualizar cliente existente
        const updatedClient = await clientService.updateClient(editingClient.id, client);
        setClients(prev => 
          prev.map(c => c.id === editingClient.id ? updatedClient : c)
        );
        setEditingClient(null);
        setShowForm(false);
      } else {
        // Criar novo cliente
        const newClient = await clientService.createClient(client);
        setClients(prev => [...prev, newClient]);
        setShowForm(false);
      }
    } catch (error) {
      console.error('Erro ao salvar cliente:', error);
      setError(error.message || 'Erro ao salvar cliente');
      throw error; // Re-throw para que o formulário possa tratar
    }
  };

  /**
   * Inicia edição de cliente
   */
  const handleEditClient = (client) => {
    setEditingClient(client);
    setShowForm(true);
    setError(null);
  };

  /**
   * Exclui cliente
   */
  const handleDeleteClient = async (clientId) => {
    try {
      setError(null);
      await clientService.deleteClient(clientId);
      setClients(prev => prev.filter(c => c.id !== clientId));
    } catch (error) {
      console.error('Erro ao excluir cliente:', error);
      setError(error.message || 'Erro ao excluir cliente');
      throw error; // Re-throw para que a lista possa tratar
    }
  };

  /**
   * Cancela edição
   */
  const handleCancelEdit = () => {
    setEditingClient(null);
    setShowForm(false);
    setError(null);
  };

  /**
   * Mostra formulário para novo cliente
   */
  const handleNewClient = () => {
    setEditingClient(null);
    setShowForm(true);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Cabeçalho */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-center">
              BradServless - Cadastro de Clientes
            </CardTitle>
            <p className="text-center text-muted-foreground">
              Sistema de gerenciamento de clientes com arquitetura serverless
            </p>
          </CardHeader>
        </Card>

        {/* Alerta de erro global */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Controles principais */}
        <div className="flex gap-4 mb-6">
          <Button onClick={handleNewClient} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Novo Cliente
          </Button>
          
          <Button 
            variant="outline" 
            onClick={fetchClients}
            disabled={isLoading}
            className="flex items-center gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            Atualizar Lista
          </Button>
        </div>

        {/* Formulário de cliente */}
        {showForm && (
          <div className="mb-8">
            <ClientForm
              client={editingClient}
              onSave={handleSaveClient}
              onCancel={handleCancelEdit}
            />
            <Separator className="mt-8" />
          </div>
        )}

        {/* Lista de clientes */}
        <ClientList
          clients={clients}
          onEdit={handleEditClient}
          onDelete={handleDeleteClient}
          isLoading={isLoading}
        />

        {/* Informações de desenvolvimento */}
        <Card className="mt-8">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground text-center">
              <p>
                <strong>Modo de Desenvolvimento:</strong> Esta aplicação está configurada para se conectar 
                com o backend serverless na AWS.
              </p>
              <p className="mt-2">
                Configure a variável de ambiente <code>VITE_API_BASE_URL</code> para apontar 
                para sua API Gateway.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

