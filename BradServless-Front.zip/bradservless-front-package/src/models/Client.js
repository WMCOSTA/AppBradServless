/**
 * Modelo de dados para Cliente
 */
export class Client {
  constructor(id = null, nome = '', email = '', telefone = '') {
    this.id = id;
    this.nome = nome;
    this.email = email;
    this.telefone = telefone;
  }

  /**
   * Valida os dados do cliente
   * @returns {Object} Objeto com isValid e errors
   */
  validate() {
    const errors = [];

    if (!this.nome || this.nome.trim().length === 0) {
      errors.push('Nome é obrigatório');
    }

    if (!this.email || this.email.trim().length === 0) {
      errors.push('Email é obrigatório');
    } else if (!this.isValidEmail(this.email)) {
      errors.push('Email deve ter um formato válido');
    }

    if (!this.telefone || this.telefone.trim().length === 0) {
      errors.push('Telefone é obrigatório');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Valida formato do email
   * @param {string} email 
   * @returns {boolean}
   */
  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Converte para objeto simples
   * @returns {Object}
   */
  toJSON() {
    return {
      id: this.id,
      nome: this.nome,
      email: this.email,
      telefone: this.telefone
    };
  }

  /**
   * Cria instância a partir de objeto
   * @param {Object} data 
   * @returns {Client}
   */
  static fromJSON(data) {
    return new Client(data.id, data.nome, data.email, data.telefone);
  }
}

